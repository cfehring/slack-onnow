# slack-onnow
Pulls URLs from onnow from Pac-12 API for Slack
